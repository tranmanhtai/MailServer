package com.blogspot.sontx.chatsocket.lib.event;

import lombok.Data;

@Data
public class AppShutdownEvent {
}
