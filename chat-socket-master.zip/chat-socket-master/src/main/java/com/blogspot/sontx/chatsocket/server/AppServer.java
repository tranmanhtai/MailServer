package com.blogspot.sontx.chatsocket.server;

import com.blogspot.sontx.chatsocket.lib.platform.Platform;

/**
 * Server entry point.
 */
public interface AppServer {
    void start(Platform platform);
}
