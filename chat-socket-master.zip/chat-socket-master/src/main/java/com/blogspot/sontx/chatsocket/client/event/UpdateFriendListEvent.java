package com.blogspot.sontx.chatsocket.client.event;

import lombok.Data;

@Data
public class UpdateFriendListEvent {
}
