package com.blogspot.sontx.chatsocket.lib;

public interface Function<T> {
    T call();
}
