package com.blogspot.sontx.chatsocket.server.view;

public interface LogView {
    void appendLog(String message);

    void clearLog();
}
