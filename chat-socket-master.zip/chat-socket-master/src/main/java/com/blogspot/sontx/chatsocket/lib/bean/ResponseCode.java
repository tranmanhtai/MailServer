package com.blogspot.sontx.chatsocket.lib.bean;

public enum ResponseCode {
    OK,
    Fail
}
