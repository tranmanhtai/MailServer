package com.blogspot.sontx.chatsocket.server.event;

import lombok.Data;

/**
 * Stops server command.
 */
@Data
public class StopServerEvent {
}
