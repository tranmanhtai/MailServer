package com.blogspot.sontx.chatsocket;

/**
 * The main entry of application.
 */
public class Program {
    public static void main(String[] args) {
        new Bootstrap().boot(args);
    }
}
