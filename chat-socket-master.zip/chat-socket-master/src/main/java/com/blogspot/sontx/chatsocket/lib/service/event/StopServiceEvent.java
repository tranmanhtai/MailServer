package com.blogspot.sontx.chatsocket.lib.service.event;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class StopServiceEvent {
    private int id;
}
