package com.blogspot.sontx.chatsocket.client;

import com.blogspot.sontx.chatsocket.lib.platform.Platform;

/**
 * Client entry point.
 */
public interface AppClient {
    void start(Platform platform);
}
