package com.blogspot.sontx.chatsocket.client.event;

public class OpenRegisterEvent {
}
