package com.blogspot.sontx.chatsocket.lib;

public interface Callback<T> {
    void call(T obj);
}
