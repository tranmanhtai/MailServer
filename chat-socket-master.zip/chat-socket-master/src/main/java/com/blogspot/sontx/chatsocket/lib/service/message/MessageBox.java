package com.blogspot.sontx.chatsocket.lib.service.message;

public interface MessageBox {
    void show(String caption, String text, MessageType type);
}
