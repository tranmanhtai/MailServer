package com.blogspot.sontx.chatsocket.lib.service.message;

public enum MessageType {
    Info,
    Error
}
