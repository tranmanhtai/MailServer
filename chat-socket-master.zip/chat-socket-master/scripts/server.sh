#!/usr/bin/env bash
java -jar homechat.jar --mode=server