#!/usr/bin/env bash
cd ../
mvn clean compile assembly:single